﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System.Collections;
using Org.BouncyCastle;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;


namespace Projekt_AES
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        { 
            InitializeComponent();
            
        }
        Encryptor enc;

        public static String mode;
        public static FileStream fileStream;
        //public static FileStream fileStreamEncrypted;
        Aes myAes = Aes.Create();
        byte[] encryptedText = null;
        string decryptedText;
        byte[] data;
        public static string InputFile { get; set; }
        public static string OutputFile { get; set; }

        //public List<string> userList;
        //public List<string> passwordList;

        ArrayList userList = new ArrayList();
        ArrayList passwordList = new ArrayList();
        public string login;
        public string password;

        public static string publicOnlyKeyXML;
        public static string privateOnlyKeyXML;

        public List<User> Users { get; set; }
        
        
        private void chooseFileClick(object sender, EventArgs e)
        { 
            var openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);    
        
            //OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    InputFile = openFileDialog.FileName;
                    InputFilePathName.Content = InputFile; //przypisanie do labela sciezki

                    fileStream = new FileStream(openFileDialog.FileName, FileMode.Open);
                    data = new byte[fileStream.Length];
                    fileStream.Read(data, 0, (int)fileStream.Length);
                    fileStream.Close();

                }
                catch (Exception)
                {
                    MessageBox.Show("Błąd !");
                }
            }
        }

        private void encryptFileClick(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(InputFile) && (!string.IsNullOrEmpty(OutputFile)))
            {
                var users = KeysListBox.Items;
                if (users.Count > 0)
                {
                    var mode = EncryptionMode.Text;
                    var keyLength = Int32.Parse(KeyLength.Text);
                    int blockLength = 0;

                    if (mode == "CFB" || mode == "OFB")
                        blockLength = Int32.Parse(SubBlockLength.Text);

                    var approvedUsers = new List<string>();
                    foreach (var u in users)
                    {
                        approvedUsers.Add(u.ToString());
                    }

                    enc = new Encryptor(mode, keyLength, blockLength, approvedUsers);
                    enc.encrypt();
                }
                else
                {
                    MessageBox.Show("Nie wybrano odbiorcow");
                }
            }
            else
            {
                MessageBox.Show("Nie wybrano pliku wejsciowego lub wyjsciowego");
            }


            /*
            try
            {
                mode = EncryptionMode.SelectedItem.ToString().Remove(0, EncryptionMode.SelectedItem.ToString().Length - 3);

                string var = System.Text.Encoding.Default.GetString(data);

                encryptedText = encryptStringToBytes(var, myAes.Key, myAes.IV);

                MessageBox.Show("Zaszyfrowano plik!");

            }
            catch (NullReferenceException ex)
            {
                if (fileStream == null)
                    MessageBox.Show("Nie wybrano pliku do szyfrowania!!!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                else
                    MessageBox.Show("Nie wybrano metody szyfrowania!!!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            */
        }

        private void decryptFileClick(object sender, RoutedEventArgs e)
        {
            decryptedText = decryptStringFromBytes(encryptedText, myAes.Key, myAes.IV);

            MessageBox.Show("Odszyfrowano tekst");
            MessageBox.Show(decryptedText);
        }

        private void writeFileClick(object sender, RoutedEventArgs e)
        {
           // if (encryptedText != null)
            //{
                var saveFileDialog = new SaveFileDialog();
                 saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                //SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        OutputFile = saveFileDialog.FileName;
                        OutputFilePathName.Content = OutputFile; //przypisanie do labela sciezki
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Błąd !");
                    }
                    /*
                    if (saveFileDialog.FileName != "")
                    {
                        fileStreamEncrypted = new FileStream(saveFileDialog.FileName, FileMode.Create);
                        fileStreamEncrypted.Write(encryptedText, 0, encryptedText.Length);
                        fileStreamEncrypted.Close();
                    }
                    */
                }
            //}
        }
        


        // Encrypt the string to an array of bytes.
        private static byte[] encryptStringToBytes(string data, byte[] key, byte[] initVector)
        {
            byte[] encrypted;
            // Create an Aes object with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = key;
                aesAlg.IV = initVector;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(data);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            
            // Return the encrypted bytes from the memory stream.
            return encrypted;
        }

        // Decrypt the bytes to a string.
        static string decryptStringFromBytes(byte[] cipherText, byte[] key, byte[] initVector)
        {
            string decryptedText = null;

            // Create an Aes object with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = key;
                aesAlg.IV = initVector;

                // Create a decryptor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting stream and place them in a string.
                            decryptedText = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return decryptedText;
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string uzytkownik = this.UserNameLogin.Text;
            string haslo = this.PasswordLogin.Password;

        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
             login = UserNameRegister.Text;
             password = PasswordRegister.Password.ToString();

            //string data = login + Environment.NewLine + password;
            //string path = @"C:\Users\ruchn\Desktop\ala.pub.txt";
            //File.WriteAllText(path, data);

            var rsa = new RSACryptoServiceProvider(2048);
            publicOnlyKeyXML = rsa.ToXmlString(false); //klucz publiczny

            privateOnlyKeyXML = rsa.ToXmlString(true); //klucz prywatny


            //MessageBox.Show(publicOnlyKeyXML);


            // string publicPath = @"C:\Users\ruchn\Desktop\Public\" + login + ".txt";
            string publicPath = @"C:\Users\ruchn\OneDrive\Obrazy\Public\" + login + ".txt";

            //string privatePath = @"C:\Users\ruchn\Desktop\Private\" + login + ".txt";
            string privatePath = @"C:\Users\ruchn\OneDrive\Obrazy\Private\" + login + ".txt";
           
            //FileStream fs = File.Create(path2);
            //fs.Write(array, 0, array.Length);

            //dodawanie kluczy do plików 
            //File.WriteAllText(path2, publicOnlyKeyXML);
            File.WriteAllText(publicPath, publicOnlyKeyXML);
            File.WriteAllText(privatePath, privateOnlyKeyXML);


            MessageBox.Show("Dodano uzytkownika!");

        }

        private void AddRecipient_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog();
            ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.Multiselect = true;

            //ofd.Filter = "*.public";
            ofd.Filter = "Public key files | *.txt";

            if (ofd.ShowDialog() == true)
            {
                try
                {
                    foreach (var file in ofd.FileNames)
                    {
                        //var name = Path.GetFileNameWithoutExtension(file);
                        var name = System.IO.Path.GetFileNameWithoutExtension(file);

                        KeysListBox.Items.Add(name);

                        /*
                        if (Users.FirstOrDefault(u => u.Name == name) == null)
                            Users.Add(new User(name));
                        else
                            MessageBox.Show("Wskazanay odbiorca jest juz dodany!");
                            */
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Blad");
                }
            }
        }
    }
}
