﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Projekt_AES
{
    public class User
    {
        public string Name { get; set; }

        public User (string name)
        {
            Name = name;
        }

        public static string getHashSha256 (string password)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(password);
            SHA256Managed sha = new SHA256Managed();
            byte[] result = sha.ComputeHash(bytes);

            //StringBuilder hashString = new StringBuilder();
            string hashString = null;

            foreach (byte b in result)
            {
                //hashString.Append(b.ToString("X2"));
                hashString += String.Format("{0:X2}", b);
            }

            return hashString;
        }


    }
}
